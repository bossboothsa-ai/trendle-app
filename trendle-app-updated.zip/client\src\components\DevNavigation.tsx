import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, Store, Shield } from "lucide-react";

export function DevNavigation() {
    const [location] = useLocation();

    if (process.env.NODE_ENV !== "development") return null;

    return (
        <div className="fixed bottom-4 right-4 z-[9999] flex gap-2 bg-black/80 p-2 rounded-full backdrop-blur shadow-2xl border border-white/20">
            <Link href="/home">
                <Button
                    variant={location.startsWith("/home") || location === "/" ? "default" : "ghost"}
                    size="sm"
                    className="rounded-full h-8 w-8 p-0"
                    title="User App"
                >
                    <Home className="h-4 w-4" />
                </Button>
            </Link>
            <Link href="/business/dashboard">
                <Button
                    variant={location.startsWith("/business") ? "default" : "ghost"}
                    size="sm"
                    className="rounded-full h-8 w-8 p-0"
                    title="Business Dashboard"
                >
                    <Store className="h-4 w-4" />
                </Button>
            </Link>
            <Link href="/admin/dashboard">
                <Button
                    variant={location.startsWith("/admin") ? "default" : "ghost"}
                    size="sm"
                    className="rounded-full h-8 w-8 p-0"
                    title="Admin Panel"
                >
                    <Shield className="h-4 w-4" />
                </Button>
            </Link>
            <div className="px-2 flex items-center text-[10px] font-bold text-green-400 select-none">
                DEV MODE
            </div>
        </div>
    );
}
