import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import BusinessLayout from "@/components/business/BusinessLayout";
import SurveyBuilder, { SurveyFormData } from "@/components/business/SurveyBuilder";
import SurveyInsights from "@/components/business/SurveyInsights";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    Plus,
    Edit,
    Trash2,
    BarChart3,
    MoreHorizontal,
    ClipboardList
} from "lucide-react";
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetDescription,
} from "@/components/ui/sheet";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
    DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { useBusiness } from "@/context/BusinessContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Survey {
    id: number;
    title: string;
    description: string;
    points: number;
    active: boolean;
    questions: any[];
    responseCount?: number;
    createdAt: string;
}

export default function Surveys() {
    const { placeId } = useBusiness();
    const { toast } = useToast();
    const queryClient = useQueryClient();

    const [isBuilderOpen, setIsBuilderOpen] = useState(false);
    const [isInsightsOpen, setIsInsightsOpen] = useState(false);
    const [selectedSurvey, setSelectedSurvey] = useState<Survey | null>(null);

    // Fetch Surveys
    const { data: surveys, isLoading } = useQuery<Survey[]>({
        queryKey: [`/api/business/surveys`, placeId],
        enabled: !!placeId,
    });

    // Create/Update Survey Mutation
    const saveSurveyMutation = useMutation({
        mutationFn: async (data: SurveyFormData) => {
            const payload = { ...data, placeId };
            if (selectedSurvey) {
                return apiRequest("PUT", `/api/business/surveys/${selectedSurvey.id}`, payload);
            } else {
                return apiRequest("POST", `/api/business/surveys`, payload);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: [`/api/business/surveys`, placeId] });
            toast({ title: selectedSurvey ? "Survey updated" : "Survey created" });
            setIsBuilderOpen(false);
            setSelectedSurvey(null);
        },
        onError: () => {
            toast({ title: "Error", description: "Failed to save survey.", variant: "destructive" });
        }
    });

    // Toggle Status Mutation
    const toggleStatusMutation = useMutation({
        mutationFn: async (id: number) => {
            return apiRequest("PATCH", `/api/business/surveys/${id}/toggle`);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: [`/api/business/surveys`, placeId] });
            toast({ title: "Status updated" });
        }
    });

    // Delete Mutation
    const deleteMutation = useMutation({
        mutationFn: async (id: number) => {
            return apiRequest("DELETE", `/api/business/surveys/${id}`);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: [`/api/business/surveys`, placeId] });
            toast({ title: "Survey deleted" });
        }
    });

    const handleCreate = () => {
        setSelectedSurvey(null);
        setIsBuilderOpen(true);
    };

    const handleEdit = (survey: Survey) => {
        setSelectedSurvey(survey);
        setIsBuilderOpen(true);
    };

    const handleInsights = (survey: Survey) => {
        setSelectedSurvey(survey);
        setIsInsightsOpen(true);
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight">Surveys</h2>
                    <p className="text-muted-foreground">Collect feedback and reward customers</p>
                </div>
                <Button onClick={handleCreate} className="bg-gradient-to-r from-purple-600 to-pink-600">
                    <Plus className="mr-2 h-4 w-4" /> Create Survey
                </Button>
            </div>

            {!surveys?.length ? (
                <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 border-none rounded-3xl">
                    <CardContent className="flex flex-col items-center justify-center py-20 text-center text-muted-foreground">
                        <div className="h-20 w-20 rounded-full bg-white shadow-lg flex items-center justify-center mb-6">
                            <ClipboardList className="h-10 w-10 text-indigo-500" />
                        </div>
                        <h3 className="text-xl font-bold text-indigo-900 mb-2">No surveys created</h3>
                        <p className="text-base text-indigo-700/70 max-w-sm mx-auto mb-8">Create your first survey to start engaging customers and gathering valuable insights.</p>
                        <Button onClick={handleCreate} className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full px-8 shadow-lg shadow-indigo-200">
                            Create Survey
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {surveys.map((survey) => (
                        <Card key={survey.id} className="group hover:-translate-y-1 hover:shadow-xl transition-all duration-300 border-none shadow-sm rounded-2xl bg-white overflow-hidden">
                            <div className={`h-2 w-full ${survey.active ? 'bg-green-500' : 'bg-gray-200'}`} />
                            <CardHeader className="pb-3 pt-5">
                                <div className="flex justify-between items-start mb-2">
                                    <Badge variant="outline" className={`${survey.active ? "bg-green-50 text-green-700 border-green-200" : "bg-gray-100 text-gray-500 border-gray-200"} rounded-lg px-2 py-0.5`}>
                                        {survey.active ? "Active" : "Paused"}
                                    </Badge>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="ghost" size="icon" className="h-8 w-8 -mr-2 text-gray-400 hover:text-gray-600">
                                                <MoreHorizontal className="h-5 w-5" />
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end" className="rounded-xl">
                                            <DropdownMenuItem onClick={() => handleEdit(survey)}>
                                                <Edit className="mr-2 h-4 w-4" /> Edit
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => handleInsights(survey)}>
                                                <BarChart3 className="mr-2 h-4 w-4" /> Insights
                                            </DropdownMenuItem>
                                            <DropdownMenuSeparator />
                                            <DropdownMenuItem onClick={() => toggleStatusMutation.mutate(survey.id)}>
                                                {survey.active ? "Pause Survey" : "Activate Survey"}
                                            </DropdownMenuItem>
                                            <DropdownMenuItem onClick={() => deleteMutation.mutate(survey.id)} className="text-red-600 focus:text-red-600 focus:bg-red-50">
                                                <Trash2 className="mr-2 h-4 w-4" /> Delete
                                            </DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </div>
                                <CardTitle className="text-xl font-bold leading-tight text-gray-900">{survey.title}</CardTitle>
                                <CardDescription className="line-clamp-2 h-10 mt-1 text-gray-500">{survey.description}</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="flex justify-between items-center bg-gray-50 rounded-xl p-3 mb-4">
                                    <div className="text-center">
                                        <span className="block font-bold text-gray-900 text-lg">{survey.points}</span>
                                        <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Points</span>
                                    </div>
                                    <div className="h-8 w-[1px] bg-gray-200"></div>
                                    <div className="text-center">
                                        <span className="block font-bold text-gray-900 text-lg">{survey.responseCount || 0}</span>
                                        <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Responses</span>
                                    </div>
                                </div>
                                <Button
                                    variant="outline"
                                    className="w-full border-2 border-indigo-50 text-indigo-600 hover:bg-indigo-50 hover:text-indigo-700 hover:border-indigo-100 rounded-xl font-bold transition-all"
                                    onClick={() => handleInsights(survey)}
                                >
                                    <BarChart3 className="mr-2 h-4 w-4" /> View Insights
                                </Button>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}

            {/* Builder Sheet */}
            <Sheet open={isBuilderOpen} onOpenChange={setIsBuilderOpen}>
                <SheetContent className="w-full sm:max-w-xl overflow-y-auto" side="right">
                    <SheetHeader>
                        <SheetTitle>{selectedSurvey ? "Edit Survey" : "Create New Survey"}</SheetTitle>
                        <SheetDescription>
                            Design your survey questions and rewards.
                        </SheetDescription>
                    </SheetHeader>
                    <div className="mt-6">
                        <SurveyBuilder
                            initialData={selectedSurvey ? {
                                title: selectedSurvey.title,
                                description: selectedSurvey.description,
                                points: selectedSurvey.points,
                                accessRequirement: "open_to_all",
                                questions: selectedSurvey.questions || []
                            } : undefined}
                            onSubmit={(data) => saveSurveyMutation.mutate(data)}
                            isLoading={saveSurveyMutation.isPending}
                        />
                    </div>
                </SheetContent>
            </Sheet>

            {/* Insights Dialog */}
            <Dialog open={isInsightsOpen} onOpenChange={setIsInsightsOpen}>
                <DialogContent className="max-w-3xl">
                    <DialogHeader>
                        <DialogTitle>Survey Insights: {selectedSurvey?.title}</DialogTitle>
                    </DialogHeader>
                    {selectedSurvey && <SurveyInsights surveyId={selectedSurvey.id} />}
                </DialogContent>
            </Dialog>

        </div>

    );
}
