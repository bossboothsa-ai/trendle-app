import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { ReactNode } from "react";

interface ProtectedRouteProps {
    children: ReactNode;
    allowedRoles: string[];
}

/**
 * Protected Route Component
 * Enforces role-based access control on frontend routes
 * 
 * @param children - The component to render if authorized
 * @param allowedRoles - Array of roles allowed to access this route
 */
export function ProtectedRoute({ children, allowedRoles }: ProtectedRouteProps) {
    // DEV MODE: BYPASS ALL CHECKS
    return <>{children}</>;
}
