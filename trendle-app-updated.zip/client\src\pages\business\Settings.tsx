import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import BusinessLayout from "@/components/business/BusinessLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
    Building2,
    Mail,
    Lock,
    Save,
    Bell,
    Settings as SettingsIcon,
    Calendar,
    Users,
    ShieldCheck,
    CreditCard,
    ChevronRight,
    HelpCircle,
    Info,
    Camera,
    Image as ImageIcon,
    Clock,
    Phone,
    MapPin,
    Trophy,
    BadgeCheck,
    LogOut,
    Eye,
    Smartphone,
    History
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface BusinessAccount {
    id: number;
    email: string;
    businessName: string;
    category: string;
}

export default function Settings() {
    const [location, setLocation] = useLocation();
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const businessId = parseInt(localStorage.getItem("businessId") || "1");

    const { data: account, isLoading } = useQuery<BusinessAccount>({
        queryKey: [`/api/business/account/${businessId}`],
        enabled: !!businessId,
    });

    const [formData, setFormData] = useState({
        businessName: "",
        email: "",
        category: "",
        description: "The premier destination for specialty coffee and late-night creative sessions in the heart of De Waterkant.",
        phone: "+27 21 456 7890",
        address: "123 Waterkant Street, Cape Town",
    });

    useEffect(() => {
        if (account) {
            setFormData(prev => ({
                ...prev,
                businessName: account.businessName,
                email: account.email,
                category: account.category,
            }));
        }
    }, [account]);

    const updateProfileMutation = useMutation({
        mutationFn: async (data: Partial<BusinessAccount>) => {
            return apiRequest("PUT", `/api/business/account/${businessId}`, data);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: [`/api/business/account/${businessId}`] });
            toast({ title: "Profile updated", description: "Your changes have been saved." });
            if (formData.businessName) {
                localStorage.setItem("businessName", formData.businessName);
            }
        },
        onError: () => {
            toast({ title: "Error", description: "Failed to update profile", variant: "destructive" });
        }
    });

    const handleSaveProfile = (e: React.FormEvent) => {
        e.preventDefault();
        updateProfileMutation.mutate({
            businessName: formData.businessName,
            category: formData.category
        });
    };

    const handleLogout = () => {
        localStorage.removeItem("businessId");
        localStorage.removeItem("businessName");
        localStorage.removeItem("placeId");
        setLocation("/business/login");
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
            </div>
        );
    }

    return (
        <div className="space-y-10 max-w-5xl mx-auto pb-20 animate-fade-in">
            {/* 1. PAGE HEADER */}
            <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
                <div className="space-y-4">
                    <div className="flex items-center gap-2 text-purple-600 font-bold text-sm uppercase tracking-widest">
                        <SettingsIcon className="w-4 h-4" />
                        <span>Account & Venue Settings</span>
                    </div>
                    <div>
                        <h2 className="text-4xl font-extrabold tracking-tight text-gray-900 mb-1">{formData.businessName || "Ember & Oak Lounge"}</h2>
                        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-gray-500 font-medium">
                            <div className="flex items-center gap-2">
                                <BadgeCheck className="w-5 h-5 text-blue-500" />
                                <span>Managed by <span className="text-gray-900">Emily R.</span> (Manager)</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Calendar className="w-5 h-5" />
                                <span>Active Since: <span className="text-gray-900">Jan 13, 2026</span></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex gap-3 w-full md:w-auto">
                    <Button variant="outline" className="flex-1 md:flex-none border-gray-200 rounded-2xl h-12 px-6 font-bold hover:bg-gray-50">
                        <Eye className="w-4 h-4 mr-2" />
                        View Public Profile
                    </Button>
                </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column - Main Settings */}
                <div className="lg:col-span-2 space-y-8">

                    {/* 2. BUSINESS PROFILE SECTION */}
                    <Card className="border-none shadow-sm rounded-[2.5rem] overflow-hidden bg-white">
                        <CardHeader className="pt-8 px-8 pb-4">
                            <div className="flex items-center gap-4 mb-2">
                                <div className="p-3 bg-purple-100 text-purple-600 rounded-2xl">
                                    <Building2 className="h-6 w-6" />
                                </div>
                                <CardTitle className="text-2xl font-extrabold">Business Profile</CardTitle>
                            </div>
                            <CardDescription className="text-base font-medium text-gray-500">
                                This information appears on your public Trendle venue profile to help customers find and engage with you.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="px-8 pb-8 pt-4">
                            <form onSubmit={handleSaveProfile} className="space-y-8">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-2">
                                        <Label htmlFor="businessName" className="text-sm font-bold text-gray-700 ml-1 uppercase tracking-wider">Business Name</Label>
                                        <Input
                                            id="businessName"
                                            value={formData.businessName}
                                            onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                                            className="h-14 rounded-2xl border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-purple-500/20 text-lg font-medium transition-all"
                                            placeholder="Venue name"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="category" className="text-sm font-bold text-gray-700 ml-1 uppercase tracking-wider">Venue Category</Label>
                                        <Select
                                            value={formData.category}
                                            onValueChange={(val) => setFormData({ ...formData, category: val })}
                                        >
                                            <SelectTrigger className="h-14 rounded-2xl border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-purple-500/20 text-lg font-medium">
                                                <SelectValue placeholder="Select category" />
                                            </SelectTrigger>
                                            <SelectContent className="rounded-2xl border-gray-100 shadow-xl">
                                                <SelectItem value="Coffee">☕ Coffee & Cafe</SelectItem>
                                                <SelectItem value="Restaurant">🍕 Restaurant</SelectItem>
                                                <SelectItem value="Nightlife">🍸 Nightlife & Bars</SelectItem>
                                                <SelectItem value="Experience">🎡 Attractions & Experiences</SelectItem>
                                                <SelectItem value="Retail">🛍️ Retail</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <div className="flex justify-between items-center ml-1">
                                        <Label htmlFor="description" className="text-sm font-bold text-gray-700 uppercase tracking-wider">Public Description</Label>
                                        <span className="text-xs font-semibold text-gray-400">{formData.description.length}/160</span>
                                    </div>
                                    <Textarea
                                        id="description"
                                        rows={3}
                                        value={formData.description}
                                        onChange={(e) => setFormData({ ...formData, description: e.target.value.slice(0, 160) })}
                                        className="rounded-2xl border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-purple-500/20 text-base font-medium resize-none p-4"
                                        placeholder="Tell customers what makes your venue special..."
                                    />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-2">
                                        <Label htmlFor="email" className="text-sm font-bold text-gray-700 ml-1 uppercase tracking-wider">Contact Email</Label>
                                        <div className="relative">
                                            <Input
                                                id="email"
                                                value={formData.email}
                                                disabled
                                                className="h-14 rounded-2xl bg-gray-100/50 border-transparent text-gray-500 pl-11 shadow-none"
                                            />
                                            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                            <TooltipProvider>
                                                <Tooltip>
                                                    <TooltipTrigger asChild>
                                                        <div className="absolute right-4 top-1/2 -translate-y-1/2 cursor-help">
                                                            <Info className="w-4 h-4 text-gray-400" />
                                                        </div>
                                                    </TooltipTrigger>
                                                    <TooltipContent className="rounded-xl border-gray-100">
                                                        Email is locked for security. Contact support to update.
                                                    </TooltipContent>
                                                </Tooltip>
                                            </TooltipProvider>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="phone" className="text-sm font-bold text-gray-700 ml-1 uppercase tracking-wider">Phone Number (Optional)</Label>
                                        <div className="relative">
                                            <Input
                                                id="phone"
                                                value={formData.phone}
                                                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                                className="h-14 rounded-2xl border-gray-100 bg-gray-50/50 focus:bg-white pl-11 font-medium"
                                                placeholder="+27 21..."
                                            />
                                            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-6 pt-4 border-t border-gray-50">
                                    <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                                        <FileText className="w-5 h-5 text-gray-400" />
                                        Billing Information
                                    </h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                        <div className="space-y-2">
                                            <Label htmlFor="billingAddress" className="text-sm font-bold text-gray-700 ml-1 uppercase tracking-wider">Billing Address</Label>
                                            <Input
                                                id="billingAddress"
                                                value={formData.address} // Re-using address for demo if needed, but better to have separate field
                                                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                                                className="h-14 rounded-2xl border-gray-100 bg-gray-50/50 focus:bg-white font-medium"
                                                placeholder="Street address for invoices"
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <Label htmlFor="taxId" className="text-sm font-bold text-gray-700 ml-1 uppercase tracking-wider">Tax ID / VAT (Optional)</Label>
                                            <Input
                                                id="taxId"
                                                value="491029384"
                                                disabled
                                                className="h-14 rounded-2xl border-gray-100 bg-gray-50/50 focus:bg-white font-medium"
                                                placeholder="VAT Number"
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-6">
                                    <Label className="text-sm font-bold text-gray-700 ml-1 uppercase tracking-wider">Venue Branding</Label>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div className="group relative h-40 rounded-3xl border-2 border-dashed border-gray-100 bg-gray-50/30 hover:bg-purple-50/30 hover:border-purple-200 transition-all flex flex-col items-center justify-center cursor-pointer">
                                            <div className="p-3 bg-white rounded-2xl shadow-sm mb-3 group-hover:scale-110 transition-transform">
                                                <Camera className="w-5 h-5 text-purple-600" />
                                            </div>
                                            <span className="text-sm font-bold text-gray-600">Upload Venue Logo</span>
                                            <span className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-bold">Recommended: 512x512</span>
                                        </div>
                                        <div className="group relative h-40 rounded-3xl border-2 border-dashed border-gray-100 bg-gray-50/30 hover:bg-blue-50/30 hover:border-blue-200 transition-all flex flex-col items-center justify-center cursor-pointer">
                                            <div className="p-3 bg-white rounded-2xl shadow-sm mb-3 group-hover:scale-110 transition-transform">
                                                <ImageIcon className="w-5 h-5 text-blue-600" />
                                            </div>
                                            <span className="text-sm font-bold text-gray-600">Upload Cover Photo</span>
                                            <span className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-bold">Recommended: 1200x400</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-4 pt-4">
                                    <div className="flex items-center gap-2 mb-2 ml-1 text-gray-500">
                                        <Clock className="w-4 h-4" />
                                        <Label className="text-sm font-bold text-gray-700 uppercase tracking-wider">Operating Hours</Label>
                                    </div>
                                    <div className="grid gap-3">
                                        {['Monday - Friday', 'Saturday', 'Sunday'].map((day) => (
                                            <div key={day} className="flex items-center justify-between p-4 rounded-2xl bg-gray-50 border border-gray-100">
                                                <span className="font-bold text-gray-700">{day}</span>
                                                <div className="flex items-center gap-4">
                                                    <span className="font-medium text-gray-900">{day === 'Sunday' ? '10:00 - 20:00' : '07:00 - 22:00'}</span>
                                                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-lg hover:bg-white text-gray-400 hover:text-purple-600">
                                                        <ChevronRight className="w-4 h-4" />
                                                    </Button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="flex justify-end pt-6">
                                    <Button
                                        type="submit"
                                        disabled={updateProfileMutation.isPending}
                                        className="bg-gray-900 hover:bg-gray-800 text-white rounded-2xl h-14 px-10 text-lg font-bold shadow-xl shadow-gray-200 transition-all hover:translate-y-[-2px] active:translate-y-[0px]"
                                    >
                                        <Save className="mr-2 h-5 w-5" />
                                        {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>

                    {/* 3. NOTIFICATIONS SECTION */}
                    <Card className="border-none shadow-sm rounded-[2.5rem] overflow-hidden bg-white">
                        <CardHeader className="pt-8 px-8 pb-4">
                            <div className="flex items-center gap-4 mb-2">
                                <div className="p-3 bg-pink-100 text-pink-600 rounded-2xl">
                                    <Bell className="h-6 w-6" />
                                </div>
                                <CardTitle className="text-2xl font-extrabold">Notifications</CardTitle>
                            </div>
                            <CardDescription className="text-base font-medium text-gray-500">
                                Choose how Trendle keeps you informed about your venue's performance and customer activity.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="px-8 pb-10 pt-4 space-y-10">
                            <div className="space-y-6">
                                <div className="flex items-center gap-2 mb-2 ml-1 border-b border-gray-50 pb-2">
                                    <Smartphone className="w-4 h-4 text-gray-400" />
                                    <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">Activity Alerts</span>
                                </div>
                                <div className="grid gap-4">
                                    {[
                                        { label: "New Moments", desc: "When customers tag your venue in a post", checked: true },
                                        { label: "Survey Responses", desc: "When you receive new feedback ratings", checked: true },
                                        { label: "Reward Redemptions", desc: "Real-time alerts for claimed perks", checked: true },
                                        { label: "Campaign Completions", desc: "When a daily task is successfully finished", checked: false },
                                    ].map((item) => (
                                        <div key={item.label} className="flex items-center justify-between p-5 rounded-2xl bg-gray-50 hover:bg-gray-50/80 transition-colors border border-transparent hover:border-pink-100">
                                            <div className="space-y-0.5">
                                                <Label className="text-lg font-bold text-gray-900">{item.label}</Label>
                                                <p className="text-sm font-medium text-gray-500">{item.desc}</p>
                                            </div>
                                            <Switch defaultChecked={item.checked} className="data-[state=checked]:bg-pink-500" />
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="space-y-6">
                                <div className="flex items-center gap-2 mb-2 ml-1 border-b border-gray-50 pb-2">
                                    <FileText className="w-4 h-4 text-gray-400" />
                                    <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">Summary Reports</span>
                                </div>
                                <div className="grid gap-4">
                                    {[
                                        { label: "Weekly Performance Summary", desc: "A comprehensive look at traffic and engagement", checked: true },
                                        { label: "Monthly Promotion Overview", desc: "Detailed breakdown of promotion impact and costs", checked: true },
                                    ].map((item) => (
                                        <div key={item.label} className="flex items-center justify-between p-5 rounded-2xl bg-gray-50 hover:bg-gray-50/80 transition-colors border border-transparent hover:border-blue-100">
                                            <div className="space-y-0.5">
                                                <Label className="text-lg font-bold text-gray-900">{item.label}</Label>
                                                <p className="text-sm font-medium text-gray-500">{item.desc}</p>
                                            </div>
                                            <Switch defaultChecked={item.checked} className="data-[state=checked]:bg-blue-500" />
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Right Column - Secondary Settings */}
                <div className="space-y-8">

                    {/* 5. ACCOUNT PLAN SECTION */}
                    <Card className="border-none shadow-sm rounded-[2.5rem] overflow-hidden bg-gray-900 text-white">
                        <CardHeader className="pt-8 px-8">
                            <div className="flex justify-between items-start">
                                <div className="p-3 bg-white/10 rounded-2xl">
                                    <FileText className="h-6 w-6 text-purple-400" />
                                </div>
                                <Badge className="bg-purple-500 text-white border-none rounded-lg px-3 py-1 font-bold">ACTIVE</Badge>
                            </div>
                            <div className="mt-6">
                                <CardTitle className="text-2xl font-extrabold text-white">Growth Plan</CardTitle>
                                <CardDescription className="text-gray-400 font-medium">Payment Method: Invoice</CardDescription>
                            </div>
                        </CardHeader>
                        <CardContent className="px-8 pb-8">
                            <div className="mt-6 space-y-4">
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-gray-400 font-medium">Next Invoice</span>
                                    <span className="text-white font-bold">Mar 1, 2026</span>
                                </div>
                                <Separator className="bg-white/10" />
                                <ul className="space-y-3">
                                    {[
                                        "Venue Profile",
                                        "Campaign Tools",
                                        "Survey Insights",
                                        "Promotion Impact Reports"
                                    ].map(feature => (
                                        <li key={feature} className="flex items-center gap-2 text-sm font-medium">
                                            <BadgeCheck className="w-4 h-4 text-purple-400" />
                                            <span>{feature}</span>
                                        </li>
                                    ))}
                                </ul>
                                <div className="pt-4 grid gap-3">
                                    <Button className="w-full bg-white text-gray-900 hover:bg-gray-100 rounded-2xl font-bold h-12 transition-all">
                                        View Invoices
                                    </Button>
                                    <Button variant="ghost" className="w-full text-gray-400 hover:text-white hover:bg-white/5 rounded-2xl font-bold h-12 transition-all">
                                        Contact Support
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* 4. SECURITY SECTION */}
                    <Card className="border-none shadow-sm rounded-[2.5rem] overflow-hidden bg-white">
                        <CardHeader className="pt-8 px-8 pb-4">
                            <div className="flex items-center gap-4 mb-2">
                                <div className="p-3 bg-blue-100 text-blue-600 rounded-2xl">
                                    <Lock className="h-6 w-6" />
                                </div>
                                <CardTitle className="text-xl font-extrabold">Security</CardTitle>
                            </div>
                        </CardHeader>
                        <CardContent className="px-8 pb-10 pt-4 space-y-8">
                            <div className="space-y-4">
                                <div className="p-5 border border-gray-100 rounded-[2rem] bg-gray-50/50">
                                    <div className="flex justify-between items-start mb-2">
                                        <h4 className="font-bold text-gray-900">Password</h4>
                                        <ShieldCheck className="w-4 h-4 text-gray-300" />
                                    </div>
                                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-4">Last changed 3 months ago</p>
                                    <Button variant="outline" className="w-full rounded-xl border-gray-200 font-bold hover:bg-white bg-white text-sm shadow-none">
                                        Change Password
                                    </Button>
                                </div>

                                <div className="p-5 border border-gray-100 rounded-[2rem] bg-gray-50/50">
                                    <div className="flex justify-between items-start mb-2">
                                        <h4 className="font-bold text-gray-900">Two-Factor Auth</h4>
                                        <Badge className="bg-gray-200 text-gray-600 border-none px-2 rounded-md font-bold text-[10px]">NOT ENABLED</Badge>
                                    </div>
                                    <p className="text-xs font-medium text-gray-500 mb-4">Add an extra layer of protection to your account.</p>
                                    <Button variant="outline" className="w-full rounded-xl border-gray-200 font-bold hover:bg-white bg-white text-sm shadow-none">
                                        Enable 2FA
                                    </Button>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <div className="flex items-center gap-2 mb-2 ml-1">
                                    <History className="w-4 h-4 text-gray-400" />
                                    <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Session Activity</span>
                                </div>
                                <div className="space-y-3">
                                    <div className="flex items-center gap-3 p-3 rounded-2xl bg-green-50/50 border border-green-100">
                                        <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-bold text-gray-900 truncate">Chrome – Cape Town</p>
                                            <p className="text-[10px] font-bold text-green-600 uppercase tracking-wider">Active Now</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-3 p-3 rounded-2xl bg-gray-50/50 opacity-60">
                                        <div className="h-2 w-2 rounded-full bg-gray-300" />
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-bold text-gray-500 truncate">Safari – London</p>
                                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">2 days ago</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Sign Out Action */}
                    <div className="grid gap-4">
                        <Button
                            variant="outline"
                            className="h-16 rounded-[2rem] border-gray-100 text-blue-600 hover:bg-blue-50/50 font-bold transition-all flex items-center justify-center gap-2 shadow-none"
                        >
                            <HelpCircle className="w-5 h-5" />
                            Browse Documentation
                        </Button>
                        <Button
                            variant="destructive"
                            onClick={handleLogout}
                            className="h-16 rounded-[2rem] bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700 border-none shadow-none font-bold transition-all flex items-center justify-center gap-2"
                        >
                            <LogOut className="w-5 h-5" />
                            Sign Out of Venue
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}

// Helper icons
function FileText(props: any) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="16" y1="13" x2="8" y2="13" />
            <line x1="16" y1="17" x2="8" y2="17" />
            <line x1="10" y1="9" x2="8" y2="9" />
        </svg>
    )
}
